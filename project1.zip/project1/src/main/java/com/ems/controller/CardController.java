package com.ems.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ems.beans.Card;
import com.ems.repositiory.CardRepositiory;


@RestController
@RequestMapping("/Card")
public class CardController 
{
	@Autowired
	private CardRepositiory cardRepositiory;
	
	@GetMapping("/readAll")
	public Iterable<Card> readAll()
	{
		Iterable<Card> all = cardRepositiory.findAll();
		return all;
	}
	@PostMapping("/create")
	public Card create(@RequestBody Card card)
	{
		return cardRepositiory.save(card);
	}
	
	@PutMapping("/update")
	public Card update(@RequestBody Card card)
	{
		return cardRepositiory.save(card);
	}


}
