package com.ems.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ems.beans.CardExpiry;
import com.ems.repositiory.CardExpiryRepositiory;


	@RestController
	@RequestMapping("/CardExpiry")
	public class CardExpiryController 
	{
		@Autowired
		private CardExpiryRepositiory cardExpiryRepositiory;
		
		@GetMapping("/readAll")
		public Iterable<CardExpiry> readAll()
		{
			Iterable<CardExpiry> all = cardExpiryRepositiory.findAll();
			return all;
		}
		@PostMapping("/create")
		public CardExpiry create(@RequestBody CardExpiry cardExpiry)
		{
			return cardExpiryRepositiory.save(cardExpiry);
		}
		
		@PutMapping("/update")
		public CardExpiry update(@RequestBody CardExpiry cardExpiry)
		{
			return cardExpiryRepositiory.save(cardExpiry);
		}



}
